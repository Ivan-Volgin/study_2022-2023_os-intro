---
## Front matter
lang: ru-RU
title: Индивидуальный проект. Этап 4.
subtitle: Основы информационной безопасности
author:
  - Волгин И.А.
institute:
  - Российский университет дружбы народов, Москва, Россия
  - 
date:27.04.2024

## i18n babel
babel-lang: russian
babel-otherlangs: english

## Formatting pdf
toc: false
toc-title: Содержание
slide_level: 2
aspectratio: 169
section-titles: true
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
---

# Информация

## Докладчик

:::::::::::::: {.columns align=center}
::: {.column width="70%"}

  * Волгин Иван Алексеевич
  * Студент по программе Компьютерные и информационные науки
  * Российский университет дружбы народов

:::
::: {.column width="30%"}
::::::::::::::

## Цель работы

Научиться использовать nikto

## Ознакомление

![](image/1.png){#fig:001 width=70%}

## Сканирование сайта с ssl

![](image/2.png){#fig:002 width=70%}

## Сканирование ip-адреса

![](image/3.png){#fig:003 width=70%}

## Получение доп. информации об ip-адресе

![](image/4.png){#fig:004 width=70%}

## Сканирование сайта с http

![Сканирование сайта с http](image/4.png){#fig:004 width=70%}

## Выводы

Я изучил nikto и попрактиковался в его использовании.
